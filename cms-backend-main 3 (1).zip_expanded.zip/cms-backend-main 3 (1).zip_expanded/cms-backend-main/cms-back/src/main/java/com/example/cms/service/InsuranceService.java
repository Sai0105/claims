package com.example.cms.service;

public interface InsuranceService {

    Integer getInsuranceAmount(String insuranceType);
}
