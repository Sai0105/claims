package com.example.cms.commons;

public enum InsuranceType {

    CAR_INSURANCE , HOME_INSURANCE , LIFE_INSURANCE
}
